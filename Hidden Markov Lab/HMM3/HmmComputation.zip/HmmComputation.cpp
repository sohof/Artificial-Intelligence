#include "HmmComputation.h"
#include <stdexcept>
#include <algorithm>
using namespace std;

HmmComputation::HmmComputation(int nrOfEmissions, Matrix * seq)
{
	NrOfEmissions = nrOfEmissions;
	Seq = seq;
}

HmmComputation::HmmComputation()
{
}

void HmmComputation::ComputeMostLikelyHiddenStateSequence(Matrix *b, Matrix *pi, Matrix*a)
{
	double *result = new double[NrOfEmissions];
	Delta = new Matrix(NrOfEmissions, b->rows);
	DeltaIdx = new Matrix(1, NrOfEmissions);
	
	CreateInitialDeltaVector(pi, b, Seq->matrix[0][0]);
	for (int i = 1; i < NrOfEmissions; i++)
	{
		int seqValue = Seq->matrix[0][i];
		CreateDeltaVector(a, b, seqValue, i);
	}

	DeltaIdx->PrintMatrix(true);
}

void HmmComputation::CreateInitialDeltaVector(Matrix *pi, Matrix *b, int seqValue)
{
	int mostLikelyState = -1;
	double maxProductValue = -1;
	for (int i = 0; i < b->rows; i++)
	{
		double product = b->matrix[i][seqValue] * pi->matrix[0][i];
		if (product > maxProductValue)
		{
			maxProductValue = product;
			mostLikelyState = i;
		}
		Delta->matrix[0][i] = product;
	}
	DeltaIdx->matrix[0][0] = mostLikelyState;
}

void HmmComputation::CreateDeltaVector(Matrix *a, Matrix *b, int seqValue, int row)
{
	for (int i = 0; i < b->rows; i++) 
	{
		double maxProb = -1;
		for (int j = 0; j < b->rows; j++)
		{
			double candidate = -1;
			candidate = a->matrix[j][i] * Delta->matrix[row - 1][j];

			if (candidate > maxProb)
				maxProb = candidate;
		}
		Delta->matrix[row][i] = maxProb * b->matrix[i][seqValue];
	}

	double largestValue = -1;
	int mostlikelyState = -1;
	for (int i = 0; i < b->rows; i++)
	{
		if (Delta->matrix[row][i] > largestValue)
		{
			largestValue = Delta->matrix[row][i];
			mostlikelyState = i;
		}
	}
	DeltaIdx->matrix[0][row] = mostlikelyState;
}

double HmmComputation::ComputeSequenceProb(Matrix *b, Matrix *pi, Matrix *a)
{
	Alpha = new Matrix(NrOfEmissions, pi->columns);
	int seqValue = Seq->matrix[0][0];
	CreateInitialAlphaPassVector(pi, b, seqValue);

	for (int i = 1; i < NrOfEmissions; i++)
	{
		seqValue = Seq->matrix[0][i];
		CreateAlphaPassVector(b, a, i, seqValue);
	}
	return Alpha->SumAtRow(NrOfEmissions - 1);
}

void HmmComputation::CreateInitialAlphaPassVector(Matrix *pi, Matrix *b, int seqCol)
{
	for (int j = 0; j < pi->columns; j++)
	{
		Alpha->matrix[0][j] = pi->matrix[0][j] * b->matrix[j][seqCol];
	}
}

void HmmComputation::CreateAlphaPassVector(Matrix *b, Matrix *a, int alphaPassRow, int seqCol)
{
	for (int j = 0; j < a->columns; j++)
	{
		double sum = 0;
		for (int k = 0; k < a->rows; k++)
		{
			sum += Alpha->matrix[alphaPassRow - 1][k] * a->matrix[k][j];
		}
		Alpha->matrix[alphaPassRow][j] = sum * b->matrix[j][seqCol];
	}
}